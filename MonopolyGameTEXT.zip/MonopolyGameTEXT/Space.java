import java.util.*;


/**
 * This abstract class creates the framework for every space to be used in the
 * gameboard
 *
 * @author William Wang, Aditya Kotak, Rahul Sarathy.
 * @version May 23, 2015
 * @author Period: 6
 * @author Assignment: MonopolyGame
 *
 * @author Sources: none
 */
public abstract class Space
{
    String name;

    int loc;

    boolean buyable;

    boolean canHaveBuildings;

    ArrayList<Player> playersOnSpace;

    GameBoard g;


    /**
     * This constructs the space object
     * 
     * @param game
     *            the gameboard the space will be created on
     * @param sloc
     *            the integer location of the space
     */
    public Space( GameBoard game, int sloc )
    {
        loc = sloc;
        g = game;
        playersOnSpace = new ArrayList<Player>();
    }


    /**
     * This method adds a player to this space using the arraylist of players on
     * this space
     * 
     * @param p
     *            the player on this space
     */
    public void addPlayer( Player p )
    {
        playersOnSpace.add( p );
    }


    /**
     * This method removes a player from this space using the arraylist of
     * players on this space
     * 
     * @param p
     *            the player on this space
     */
    public void removePlayer( Player p )
    {
        playersOnSpace.remove( playersOnSpace.indexOf( p ) );
    }


    /**
     * This method gets the name of this space
     * 
     * @return the name of this space
     */
    public String getName()
    {
        return name;

    }


    /**
     * This method gets the integer location of this space on the gameboard.
     * 
     * @return the integer location of this space on the gameboard
     */
    public int getLoc()
    {
        return loc;
    }


    /**
     * This method gets the total players on this space
     * 
     * @return all the players on this space
     */
    public ArrayList<Player> getPlayerList()
    {
        return playersOnSpace;
    }


    /**
     * This method offers the framework for the other spaces to use.
     * 
     * @param p
     *            the player on this space
     */
    public abstract void act( Player p );


    /**
     * This method gets the name of this space
     * 
     * @return the name of this space
     */
    public String toString()
    {
        return getName();

    }

}
