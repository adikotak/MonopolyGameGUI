/**
 * This class creates a taxspace to be used in the gameboard
 *
 * @author William Wang, Aditya Kotak, Rahul Sarathy.
 * @version May 23, 2015
 * @author Period: 6
 * @author Assignment: MonopolyGame
 *
 * @author Sources: none
 */
public class TaxSpace extends Space
{
    private int myPay;


    /**
     * This constructs the tax space
     * 
     * @param g
     *            the gameboard in which this taxspace will be used in
     * @param tname
     *            the name of this tax space
     * @param tloc
     *            the integer location of this taxspace
     * @param pay
     *            the amount of money needed to be paid in this space
     */
    public TaxSpace( GameBoard g, String tname, int tloc, int pay )
    {
        super( g, tloc );
        name = tname + " Tax";
        loc = tloc;
        buyable = false;
        canHaveBuildings = false;
        myPay = pay;
    }


    /**
     * This method gets the amount of money needed to be paid if landed on this
     * taxspace
     * 
     * @return the amount of money to be paid
     */
    public int payTax()
    {
        return myPay;
    }


    /**
     * This method makes the player pay if landed on this space
     * 
     * @param p
     *            the player on this space
     */
    public void act( Player p )
    {
        playersOnSpace.add( p );
        p.payBank( myPay );
        System.out.println( "You paid a $" + myPay + " tax!" );
        System.out.println( "Money: $" + p.getMoney() );
        System.out.println( "Properties: " + p.getProperties() );
        System.out.println( "RailRoads: " + p.getRailroads() );
        System.out.println( "Utilities: " + p.getUtilities() );
    }

}
