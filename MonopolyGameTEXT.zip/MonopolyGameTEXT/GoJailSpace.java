/**
 * This class creates the goJailSpace to be implemented in GameBoard.
 *
 * @author William Wang, Aditya Kotak, Rahul Sarathy.
 * @version May 23, 2015
 * @author Period: 6
 * @author Assignment: MonopolyGame
 *
 * @author Sources: none
 */
public class GoJailSpace extends Space
{
    /**
     * This constructs the go to jail space on GameBoard.
     * 
     * @param g
     *            the GameBoard that will have the go to jail space
     */
    public GoJailSpace( GameBoard g )
    {
        super( g, 30 );
        name = "Go to Jail";
        buyable = false;
        canHaveBuildings = false;
    }


    /**
     * This moves a player to jail. It will subtract $200 from the player
     * because the player does not get the money it will collect once it passes
     * go.
     * 
     * @param p
     *            the player moving to jail
     */
    public void act( Player p )
    {
        g.move( p, g.getJail() );
        p.setInJail( true );
        // p.payBank( 200 );
        System.out.println( "You have been sent to jail! You will not collect the $200 if you pass Go." );
    }
}
