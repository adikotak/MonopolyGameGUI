import java.util.*;


/**
 * This class creates the UtilitySpace object for the Monopoly game.
 *
 * @author William Wang, Aditya Kotak, Rahul Sarathy.
 * @version May 23, 2015
 * @author Period: 6
 * @author Assignment: MonopolyGame
 *
 * @author Sources: none
 */
public class UtilitySpace extends Space
{
    private Player owner;

    private Scanner in = new Scanner( System.in );

    private int mortgage;


    /**
     * Constructs the UtilitySpace to be used in the Monopoly game.
     * 
     * @param g
     *            The gameboard for which UtilitySpace is for.
     * @param uname
     *            The name of this UtilitySpace.
     * @param uloc
     *            The integer location of this UtilitySpace on the gameboard.
     */
    public UtilitySpace( GameBoard g, String uname, int uloc )
    {
        super( g, uloc );
        name = uname + " Utility";
        buyable = true;
        canHaveBuildings = false;
        mortgage = 75;
    }


    /**
     * Returns the player who is the owner of this UtilitySpace.
     * 
     * @return owner
     */
    public Player getOwner()
    {
        return owner;
    }


    /**
     * A required method since UtilitySpace extends Space that has the abstract
     * method act. This method enables Player p to purchase this utility if
     * desired. This method will check if the player has enough money purchase
     * this utility. If the owner is already set, then the Player p will pay the
     * owner the rent of this property based on the formula for multiplying
     * either 4 or 10 to the number rolled by the player to land on this
     * UtilitySpace depending on how many Utilities the owner owns.
     * 
     * @param p
     *            The Player who lands on this railroad space.
     */
    public void act( Player p )
    {
        boolean madeMove = false;
        playersOnSpace.add( p );

        if ( getOwner() == null )
        {
            if ( p.getMoney() >= 150 )
            {
                if ( p.isHuman )
                {
                    while ( !madeMove )
                    {
                        System.out.println( "You may buy this utility! Price: $" + 150 );
                        System.out.println( "Please select an option:" );
                        System.out.println( "(1) Buy Utility" );
                        System.out.println( "(2) Don't Buy Utility" );
                        String ans = in.nextLine();
                        if ( ans.equals( "1" ) )
                        {
                            System.out.println( "Congrats you've bought this utility" );
                            p.payBank( 150 );
                            p.buyUtil( this );
                            setOwner( p );
                            System.out.println( "Money: $" + p.getMoney() );
                            System.out.println( "Properties: "
                                + p.getProperties() );
                            System.out.println( "Railroads: "
                                + p.getRailroads() );
                            System.out.println( "Utilities: "
                                + p.getUtilities() );
                            madeMove = true;
                        }
                        else if ( ans.equals( "2" ) )
                        {
                            System.out.println( "You did not buy this utility." );
                            madeMove = true;
                        }
                        else
                        {
                            System.out.println( "Sorry, that is not a valid option. Please try again." );
                        }
                    }
                }
                else
                {
                    System.out.println( p.getName() + " bought " + getName()
                        + "." );
                    p.payBank( 150 );
                    p.buyUtil( this );
                    setOwner( p );
                    System.out.println( "Money: $" + p.getMoney() );
                    System.out.println( "Properties: " + p.getProperties() );
                    System.out.println( "Railroads: " + p.getRailroads() );
                    System.out.println( "Utilities: " + p.getUtilities() );
                    madeMove = true;
                }

            }
            else
            {
                System.out.println( "Sorry, you do not have enough money to buy this utility." );
            }
        }
        else
        {
            if ( !p.equals( getOwner() ) )
            {
                if ( getOwner().getUtilNum() == 1 )
                {
                    int pay = p.payPlayer( p.getMoveAmount() * 4, owner );
                    System.out.println( "You paid " + owner.getName() + " $"
                        + pay + "." );
                }
                else if ( getOwner().getUtilNum() == 2 )
                {
                    int pay = p.payPlayer( p.getMoveAmount() * 10, owner );
                    System.out.println( "You paid " + owner.getName() + " $"
                        + pay + "." );
                }
            }
        }
    }


    /**
     * Sets the owner of this UtilitySpace to Player p
     * 
     * @param p
     *            The Player who owns this UtilitySpace
     */
    public void setOwner( Player p )
    {
        owner = p;
    }


    /**
     * Gets the mortgage value of this utilityspace
     * 
     * @return the mortgage value of this utilityspace
     */
    public int getMortgage()
    {
        return mortgage;
    }
}
