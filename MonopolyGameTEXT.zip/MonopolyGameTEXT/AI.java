import java.util.*;


/**
 * The AI class defines a Player that does everything a Player would do in real
 * time, except automatically.
 *
 * @author William Wang, Aditya Kotak, Rahul Sarathy.
 * @version May 23, 2015
 * @author Period: 6
 * @author Assignment: MonopolyGame
 *
 * @author Sources: none
 */
public class AI extends Player
{
    private String name;

    private Bank b;

    private GameBoard myGame;

    private int cash;

    private ArrayList<PropertySpace> properties;

    private ArrayList<RailroadSpace> rrspace;

    private ArrayList<UtilitySpace> uspace;

    private boolean hasJailFree, inJail;

    private int numHouses, numHotels;

    private int position, prevPos;

    private ListNode2<Space> currSpace;


    /**
     * Constructor for an AI.
     * 
     * @param name
     *            name for this AI (Computer [number])
     * @param g
     *            the GameBoard this AI plays on
     */
    public AI( String name, GameBoard g )
    {
        super( name, g );
        myGame = g;
        b = myGame.getBank();
        isHuman = false;
    }


    /**
     * Method that automatically runs through all the tasks a player does,
     * complete with choice.
     */
    public void run()
    {
        int numOfDoubles = 0;
        ArrayList<Die> dice = myGame.getDice();
        dice.get( 0 ).roll();
        dice.get( 1 ).roll();
        int d1Val = dice.get( 0 ).getNumDots();
        int d2Val = dice.get( 1 ).getNumDots();
        setMoveAmount( d1Val + d2Val );
        System.out.println( getName() + " rolled a " + d1Val + " and a "
            + d2Val + "." );
        while ( d1Val == d2Val )
        {
            numOfDoubles++;
            if ( numOfDoubles >= 3 )
            {
                myGame.move( this, myGame.getJail() );
                if ( getPrevPos() > myGame.getJail().getValue().getLoc() )
                {
                    payBank( 200 );
                }
                System.out.println( "You rolled too many doubles! You have been sent to jail." );
                myGame.getJail().getValue().act( this );
                setInJail( true );
                numOfDoubles = 0;
                return;
            }
            else
            {
                ListNode2<Space> curr = myGame.move( this, d1Val + d2Val );
                System.out.println( getName() + " moved to "
                    + curr.getValue().getName() + "." );
                System.out.println();

                curr.getValue().act( this );

                if ( getPrevPos() != myGame.getGoJail().getValue().getLoc() )
                {
                    System.out.println( "You rolled doubles! You may roll again." );
                    System.out.println();
                    dice.get( 0 ).roll();
                    dice.get( 1 ).roll();
                    d1Val = dice.get( 0 ).getNumDots();
                    d2Val = dice.get( 1 ).getNumDots();
                    System.out.println( "You rolled a " + d1Val + " and a "
                        + d2Val + "." );
                }
                else
                {
                    numOfDoubles = 0;
                    return;
                }
            }
        }
        numOfDoubles = 0;
        ListNode2<Space> s = myGame.move( this, d1Val + d2Val );
        System.out.println( "You moved to " + s.getValue().getName() + "." );
        spaceAction( s );
        for ( int i = getProperties().size() - 1; i >= 0; i-- )
        {
            if ( allPropsInGroupHave4Houses( getProperties().get( i ) ) )
            {
                AIbuyHotel( getProperties().get( i ) );
            }
        }
        for ( int i = getProperties().size() - 1; i >= 0; i-- )
        {
            if ( hasAllPropsInGroup( getProperties().get( i ) ) )
            {
                AIbuyHouse( getProperties().get( i ) );
            }
        }
    }


    /**
     * This method buys houses for the AI. It budgets 75% of the current amount
     * of money to be used for buying houses.
     * 
     * @param s
     *            the property for which the house is being bought for.
     */
    public void AIbuyHouse( PropertySpace s )
    {
        if ( s.getNumOfHouses() < 4 && !allPropsInGroupHave4Houses( s )
            && !s.hasHotel() )
        {
            int hPrice = s.getHousePrice();
            int temp = getMoney();
            int numToBeBought = 0;
            while ( temp > ( getMoney() / 4 ) )
            {
                if ( temp > hPrice )
                {
                    temp -= hPrice;
                    numToBeBought++;
                }
                else
                {
                    break;
                }
            }
            if ( numToBeBought + s.getNumOfHouses() > 4 )
            {
                numToBeBought = 4 - s.getNumOfHouses();
            }
            for ( int i = 0; i < numToBeBought; i++ )
            {
                payBank( hPrice );
                s.addHouse();
                numHouses++;
            }
            if ( numToBeBought > 0 )
            {
                System.out.println( "Congrats! You bought: " + numToBeBought
                    + " house(s) on " + s.getName() );
            }
            if ( allPropsInGroupHave4Houses( s ) )
            {
                System.out.println( "You may now buy hotels for this group!" );
            }
        }
    }


    /**
     * This method buys a hotel for the AI as long as the AI has enough money
     * and there is not a hotel on the property space.
     * 
     * @param s
     *            the property space for which a hotel is being bought.
     */
    public void AIbuyHotel( PropertySpace s )
    {
        int hPrice = s.getHousePrice();
        if ( getMoney() > hPrice && !s.hasHotel() )
        {
            payBank( hPrice );
            s.addHouse();
            System.out.println( "Congrats! You bought a hotel on "
                + s.getName() );
        }
    }

}
