/**
 * This class creates a free parking space on GameBoard.
 *
 * @author William Wang, Aditya Kotak, Rahul Sarathy.
 * @version May 23, 2015
 * @author Period: 6
 * @author Assignment: MonopolyGame
 *
 * @author Sources: none
 */
public class FreeSpace extends Space
{
    /**
     * This constructs the free parking space on GameBoard.
     * 
     * @param g
     *            the GameBoard in which this free parking space will be created
     */
    public FreeSpace( GameBoard g )
    {
        super( g, 20 );
        name = "Free Parking";
        buyable = false;
        canHaveBuildings = false;
    }


    /**
     * This method does nothing because nothing is supposed to happen on the
     * free parking space.
     * 
     * @param p
     *            the player on this free parking space
     */
    public void act( Player p )
    {
        playersOnSpace.add( p );
    }

}
