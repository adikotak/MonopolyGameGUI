import java.util.*;


/**
 * This class creates a PropertySpace for use in the Monopoly game. It has
 * numerous objects needed for a fully functioning Monopoly game.
 *
 * @author William Wang, Aditya Kotak, Rahul Sarathy.
 * @version May 23, 2015
 * @author Period: 6
 * @author Assignment: MonopolyGame
 *
 * @author Sources: none
 */
public class PropertySpace extends Space
{
    private int houseCount;

    private ArrayList<House> houses;

    private ArrayList<House> hotels;

    private int rentPrice;

    private int spacePrice;

    private int housePrice;

    private int mortgagePrice;

    private boolean hasHouses;

    private boolean hasHotel;

    private Player owner;

    private int group;

    private Scanner in = new Scanner( System.in );


    /**
     * Constructs a PropertySpace.
     * 
     * @param g
     *            The GameBoard this PropertySpace uses to use GameBoard's
     *            methods.
     * @param pname
     *            The name of this property.
     * @param ploc
     *            The integer location of this property on a GameBoard
     *            LinkedList.
     * @param pgroup
     *            The group of this Property. This will correspond to the color
     *            groups known in the traditional monopoly.
     * @param rentBase
     *            The rent a player must pay to the owner when there are no
     *            houses built on this property.
     * @param space
     *            The rent a player must pay to the owner when there are no
     *            houses built on this space.
     * @param house
     *            The price to build a house on this property.
     * @param mortgage
     *            The amount of money the owner will receive if he or she
     *            chooses to mortgage this property.
     */
    public PropertySpace(
        GameBoard g,
        String pname,
        int ploc,
        int pgroup,
        int rentBase,
        int space,
        int house,
        int mortgage )
    {
        super( g, ploc );
        name = pname + " Avenue";
        buyable = true;
        canHaveBuildings = true;
        group = pgroup;
        rentPrice = rentBase;
        spacePrice = space;
        housePrice = house;
        mortgagePrice = mortgage;
        hasHouses = false;
        houses = new ArrayList<House>();
    }


    /**
     * Gets the owner of this property.
     * 
     * @return the owner of this property
     */
    public Player getOwner()
    {
        return owner;
    }


    /**
     * A required method since ProeprtySpace extends Space that has the abstract
     * method act. This method enables Player p to purchase this space if
     * desired. This method will check if the player has enough money purchase
     * this property and also checks if this transaction means an entire block
     * of properties is owned by a single owner. If the owner is already set,
     * then the Player p will pay the owner the rent of this property based on
     * the getRent() method.
     * 
     * @param p
     *            The Player who lands on this property space.
     */
    public void act( Player p )
    {
        boolean madeMove = false;
        playersOnSpace.add( p );

        if ( getOwner() == null )
        {
            if ( p.getMoney() >= spacePrice )
            {
                if ( p.isHuman )
                {
                    while ( !madeMove )
                    {
                        System.out.println( "You may buy this property! Price: $"
                            + spacePrice );
                        System.out.println( "Please select an option:" );
                        System.out.println( "(1) Buy Property" );
                        System.out.println( "(2) Don't Buy Property" );
                        String ans = in.nextLine();
                        if ( ans.equals( "1" ) )
                        {
                            System.out.println( "Congrats you've bought this property" );
                            p.payBank( spacePrice );
                            p.buyProp( this );
                            setOwner( p );
                            System.out.println( "Money: $" + p.getMoney() );
                            System.out.println( "Properties: "
                                + p.getProperties() );
                            System.out.println( "Railroads: "
                                + p.getRailroads() );
                            System.out.println( "Utilities: "
                                + p.getUtilities() );
                            if ( p.hasAllPropsInGroup( this ) )
                            {
                                System.out.println( "You may now buy houses on this property block!" );
                                System.out.println( "These properties are now double rent!" );
                            }
                            madeMove = true;
                        }
                        else if ( ans.equals( "2" ) )
                        {
                            System.out.println( "You did not buy this property." );
                            madeMove = true;
                        }
                        else
                        {
                            System.out.println( "Sorry, that is not a valid option. Please try again." );
                        }
                    }
                }
                else
                {
                    System.out.println( p.getName() + " bought " + getName()
                        + "." );
                    p.payBank( spacePrice );
                    p.buyProp( this );
                    setOwner( p );
                    System.out.println( "Money: $" + p.getMoney() );
                    System.out.println( "Properties: " + p.getProperties() );
                    System.out.println( "Railroads: " + p.getRailroads() );
                    System.out.println( "Utilities: " + p.getUtilities() );
                    if ( p.hasAllPropsInGroup( this ) )
                    {
                        System.out.println( "You may now buy houses on this property block!" );
                        System.out.println( "These properties are now double rent!" );
                    }
                    madeMove = true;
                }
            }
            else
            {
                System.out.println( "Sorry, you do not have enough money to buy this property." );
            }
        }
        else
        {
            if ( !p.equals( getOwner() ) )
            {

                int pay = p.payPlayer( getRent( owner ), owner );
                System.out.println( "You paid " + owner.getName() + " $" + pay
                    + "." );
            }
        }
    }


    public void setHousePrice( int n )
    {
        housePrice = n;
    }


    /**
     * Gets the house price for this PropertySpace.
     * 
     * @return housePrice
     */
    public int getHousePrice()
    {
        return housePrice;

    }


    /**
     * Adds a house to this property through the use of an ArrayList. Checks if
     * adding a house will exceed 5 houses and denies the player from buying a
     * house. If the house being bought is the 5th house on this PropertySpace,
     * this method will add a Hotel to this property.
     */
    public void addHouse()
    {
        houseCount++;
        if ( houseCount > 5 )
        {
            System.out.println( "You already have the maximum amount of buildings on this property!" );
            houseCount--;
        }
        else if ( houseCount == 5 )
        {
            hasHotel = true;
            getOwner().setNumHouses( getOwner().getNumHouses() - 4 );
            getOwner().setNumHotels( getOwner().getNumHotels() + 1 );
            // add some code to implement hotels
        }
        else
        {
            houses.add( new House( houses.size(), housePrice ) );
            getOwner().setNumHouses( getOwner().getNumHouses() + 1 );
        }
        hasHouses = true;
    }


    /**
     * Removes a house on this PropertySpace. This method checks if the amount
     * of houses is five. If it is so, it will subtract the total number of
     * hotels of the owner by 1 and add 4 to the number of houses because a
     * hotel is merely 5 houses. If there are no houses on this property to
     * remove, it will tell the user that removing a house is not allowed.
     */
    public void removeHouse()
    {
        if ( houseCount == 5 )
        {
            hasHotel = false;
            getOwner().setNumHouses( getOwner().getNumHouses() + 4 );
            getOwner().setNumHotels( getOwner().getNumHotels() - 1 );
            houseCount--;
        }
        else if ( houseCount <= 0 )
        {
            System.out.println( "There are no houses to sell." );
        }
        else
        {
            houses.remove( 0 );
            getOwner().setNumHouses( getOwner().getNumHouses() - 1 );
            houseCount--;
        }
        if ( houseCount == 0 )
        {
            hasHouses = false;
        }
    }


    /**
     * Returns the number of houses on this PropertySpace in order to ensure the
     * limit does not get exceeded.
     * 
     * @return houseCount
     */
    public int getNumOfHouses()
    {
        return houseCount;
    }


    public void setOrgRent( int n )
    {
        rentPrice = n;
    }


    /**
     * Returns the original rent of this PropertySpace to be used in the main
     * getRent() method;
     * 
     * @return rentPrice
     */
    public int getOrgRent()
    {
        return rentPrice;
    }


    /**
     * Sets the owner of this PropertySpace to Player p
     * 
     * @param p
     *            The Player who has bought this PropertySpace
     */
    public void setOwner( Player p )
    {
        owner = p;
    }


    public void setGroup( int n )
    {
        group = n;

    }


    /**
     * Returns the group number of this PropertySpace which is equivalent of a
     * color from the original game.
     * 
     * @return group
     */
    public int getGroup()
    {
        return group;
    }


    /**
     * Gets the rent of this PropertySpace based on how many houses are bought
     * on this PropertySpace.
     * 
     * @param p
     *            The Player who owns this property.
     * @return An integer value representing the rent of this property.
     */
    public int getRent( Player p )
    {
        if ( p.hasAllPropsInGroup( this ) )
        {
            if ( houseCount == 0 )
            {
                return getOrgRent() * 2;

            }
            else if ( houseCount == 1 )
            {
                return ( getOrgRent() * 5 );
            }
            else if ( houseCount == 2 )
            {
                return getOrgRent() * 10;
            }
            else if ( houseCount == 3 )
            {
                return ( getOrgRent() * 20 );
            }
            else if ( houseCount == 4 )
            {
                return getOrgRent() * 25;
            }
            else
            {
                return getOrgRent() * 40;
            }
        }
        else
        {
            return getOrgRent();
        }

    }


    /**
     * Checks whether this PropertySpace has a hotel built on it.
     * 
     * @return hasHotel
     */
    public boolean hasHotel()
    {
        return hasHotel;
    }


    /**
     * Checks whether this PropertySpace has a house built on it.
     * 
     * @return hasHotel
     */
    public boolean hasHouses()
    {
        return hasHouses;
    }


    public void setMortgage( int n )
    {
        mortgagePrice = n;
    }


    /**
     * Gets the mortgage value of this PropertySpace
     * 
     * @return the mortgage value of this property
     */
    public int getMortgage()
    {
        return mortgagePrice;
    }
}
