/**
 * This class creates a Chance space that will be found on the physical Monopoly
 * board.
 *
 * @author William Wang, Aditya Kotak, Rahul Sarathy.
 * @version May 23, 2015
 * @author Period: 6
 * @author Assignment: MonopolyGame
 *
 * @author Sources: none
 */
public class ChanceSpace extends Space
{
    /**
     * This constructs a Chance space on GameBoard.
     * 
     * @param g
     *            the GameBoard this Chance space is to be built on
     * @param location
     *            the integer location in the GameBoard
     */
    public ChanceSpace( GameBoard g, int location )
    {
        super( g, location );
        name = "Chance";
        buyable = false;
        canHaveBuildings = false;
    }


    /**
     * This will call a player's drawChance() method which will execute the
     * method use() in the Chance class.
     * 
     * @param p
     *            the player on this chance space
     */
    public void act( Player p )
    {
        playersOnSpace.add( p );
        p.drawChance();
    }
}
