/**
 * This class creates a community chest space that will be found on the physical
 * gameboard.
 *
 * @author William Wang, Aditya Kotak, Rahul Sarathy.
 * @version May 23, 2015
 * @author Period: 6
 * @author Assignment: MonopolyGame
 *
 * @author Sources: none
 */
public class CommunityChestSpace extends Space
{
    /**
     * This constructs a community chest space on the gameboard
     * 
     * @param g
     *            the gameboard this community chest space is to be built on
     * @param location
     *            the integer location in the gameboard
     */
    public CommunityChestSpace( GameBoard g, int location )
    {
        super( g, location );
        name = "Community Chest";
        buyable = false;
        canHaveBuildings = false;
    }


    /**
     * This will call a player's draw community chest method which will execute
     * the method use in the community chest class.
     * 
     * @param p
     *            the player on this chance space
     */
    public void act( Player p )
    {
        playersOnSpace.add( p );
        p.drawCC();
    }
}
