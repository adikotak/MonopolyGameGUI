import java.util.ArrayList;


/**
 * This class creates a Go space which is the first space on the GameBoard.
 *
 * @author William Wang, Aditya Kotak, Rahul Sarathy.
 * @version May 23, 2015
 * @author Period: 6
 * @author Assignment: MonopolyGame
 *
 * @author Sources: none
 */
public class GoSpace extends Space
{
    private Bank b;


    /**
     * This constructs the Go space on the GameBoard.
     * 
     * @param g
     *            the game board that has this go space
     */
    public GoSpace( GameBoard g )
    {
        super( g, 0 );
        name = "Go";
        buyable = false;
        canHaveBuildings = false;
        b = g.getBank();
    }


    /**
     * This method prints out when a player is on this go space. It does not pay
     * a player because that is done in the player move method.
     * 
     * @param p
     *            the player on this go space
     */
    public void act( Player p )
    {
        playersOnSpace.add( p );
    }
}
