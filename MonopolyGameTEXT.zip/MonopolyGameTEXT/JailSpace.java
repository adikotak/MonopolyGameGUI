import java.util.ArrayList;


/**
 * This class creates a JailSpace object to be used in the Monopoly game.
 *
 * @author William Wang, Aditya Kotak, Rahul Sarathy.
 * @version May 23, 2015
 * @author Period: 6
 * @author Assignment: MonopolyGame
 *
 * @author Sources: none
 */
public class JailSpace extends Space
{
    private ArrayList<Player> playersInJail;

    private int tries;

    private boolean inJail;

    private boolean rolledDoubles;

    private ArrayList<Die> d;


    /**
     * Constructs the JailSpace to be used in GameBoard.
     * 
     * @param g
     *            The GameBoard that will have this JailSpace
     */
    public JailSpace( GameBoard g )
    {
        super( g, 10 );
        name = "Jail";
        buyable = false;
        canHaveBuildings = false;
        playersInJail = new ArrayList<Player>();
        d = g.getDice();
        tries = 0;
        inJail = false;
        rolledDoubles = false;
    }


    /**
     * This method adds a player to jail.
     * 
     * @param p
     *            The player to be moved into jail
     */
    public void addToJail( Player p )
    {
        playersInJail.add( p );
    }


    /**
     * This method lets a player roll two dice in order to try to be released
     * from jail if doubles are rolled.
     * 
     * @param dice
     *            the two die in an arraylist to be used to remove the player in
     *            jail
     * @param p
     *            the player in jail
     * @return true if the player has made a move
     */
    public boolean inJailRollDie( ArrayList<Die> dice, Player p )
    {
        Die d1 = dice.get( 0 );
        Die d2 = dice.get( 1 );
        d1.roll();
        d2.roll();
        System.out.println( "You rolled a " + d1.getNumDots() + " and a "
            + d2.getNumDots() + "." );

        tries++;

        if ( d1.getNumDots() == d2.getNumDots() )
        {
            System.out.println( "You rolled doubles! You are free from Jail!" );
            rolledDoubles = true;
            p.setInJail( false );
            removeFromJail( p );
            ListNode2<Space> curr = p.move( d1.getNumDots() + d2.getNumDots() );
            System.out.println( "You moved to " + curr.getValue().getName()
                + "." );
        }
        else if ( tries == 3 )
        {
            System.out.println( "You served your sentence and paid $50! You are free from Jail!" );
            p.payBank( 50 );
            p.setInJail( false );
            removeFromJail( p );
            ListNode2<Space> curr = p.move( d1.getNumDots() + d2.getNumDots() );
            System.out.println( "You moved to " + curr.getValue().getName()
                + "." );
            curr.getValue().act( p );
        }
        return true;
    }


    /**
     * This method allows a player to pay $50 to be removed from jail. This
     * method makes sure the player has enough money.
     * 
     * @param p
     *            the player in jail
     * @return true if the player has paid out of jail.
     */
    public boolean payOutOfJail( Player p )
    {
        if ( p.getMoney() > 50 )
        {
            System.out.println( "You paid $50! You are free from Jail!" );
            p.payBank( 50 );
            p.setInJail( false );
            removeFromJail( p );
            return true;
        }
        else
        {
            System.out.println( "You do not have enough money." );
            return false;
        }

    }


    /**
     * This method allows a user to use a get out of jail free card to get
     * removed from jail. This method checks if the player has the get out of
     * jail free card.
     * 
     * @param p
     *            the player in jail
     * @return true if the player used the get out of jail free card
     */
    public boolean useCard( Player p )
    {
        if ( p.getHasJailFree() )
        {
            p.setHasJailFree( false );
            p.setInJail( false );
            removeFromJail( p );
            return true;
        }
        else
        {
            System.out.println( "You do not have a Get-Out-Of-Jail-Free card." );
            return false;
        }
    }


    /**
     * This removes the player from the jail space
     * 
     * @param p
     *            the player in jail
     */
    public void removeFromJail( Player p )
    {
        playersInJail.remove( p );
    }


    /**
     * This method moves a player to jail and sets his or her standing with
     * jail.
     * 
     * @param p
     *            the player in question
     */
    public void act( Player p )
    {
        if ( g.getGoJail().getValue().getLoc() == p.getPrevPos() )
        {
            addToJail( p );
            p.setInJail( true );
        }
        else
        {
            playersOnSpace.add( p );
            p.setInJail( false );
        }
    }


    /**
     * This method allows three switch cases for the player to choose which
     * option to use in order to get out of jail
     * 
     * @param p
     *            the player in jail
     * @param option
     *            the string inputed in by the player
     * @return true if the person is out of jail
     */
    public boolean actJail( Player p, String option )
    {
        boolean madeMove;
        switch ( option )
        {
            case "1":
                madeMove = inJailRollDie( d, p );
                break;
            case "2":
                madeMove = payOutOfJail( p );
                break;
            case "3":
                madeMove = useCard( p );
                break;
            default:
                System.out.println( "Invalid Option" );
                madeMove = false;
                break;
        }
        return madeMove;
    }


    /**
     * This method uses the a space to set the goJailSpace.
     * 
     * @param goJail
     *            the space that refers to the goJailSpace
     */
    public void setGoJail( ListNode2<Space> goJail )
    {
        goJail = g.getGoJail();
    }


    /**
     * this method gets the tries of the player
     * 
     * @return the tries
     */
    public int getTries()
    {
        return tries;
    }
}
