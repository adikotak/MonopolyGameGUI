import java.util.ArrayList;
import java.util.Scanner;

import junit.framework.TestCase;


/**
 * This is the JUnit test in order to ensure we are coding our project
 * correctly.
 *
 * @author William Wang, Aditya Kotak, Rahul Sarathy.
 * @version May 23, 2015
 * @author Period: 6
 * @author Assignment: MonopolyGame
 *
 * @author Sources: none
 */
public class MonopolyTest extends TestCase
{
    Scanner s = new Scanner( System.in );


    /**
     * This method tests if the player properly passes go.
     */
    public void testGo()
    {
        // g.startGame();
        GameBoard g = new GameBoard( s, 2, 0 );

        ListNode2<Space> go = g.getGo();
        Player one = g.getPlayers().remove();

        int p1money = one.getMoney();
        g.move( one, g.getProperty( "Boardwalk Avenue" ) );
        g.move( one, 11 );

        assertEquals( p1money + 200, one.getMoney() );
    }


    /**
     * This method tests whether the player properly rolled doubles.
     */
    /**
     * public void testDoubles() { GameBoard g = new GameBoard(s, 2, 0);
     * ArrayList<Die> store = g.getDice(); if (store.get(0).getNumDots() ==
     * store.get(1).getNumDots()) { assertEquals( store.get(0).getNumDots() ==
     * store.get(1).getNumDots(), true); } else { assertEquals(
     * store.get(0).getNumDots() == store.get(1).getNumDots(), false); } }
     **/

    /**
     * This method tests gameBoard getBank method
     */
    public void testGetBank()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Bank b = new Bank();
        g.setBank( b );
        assertEquals( g.getBank(), b );
    }


    /**
     * This method tests gameBoard getBoard method
     */
    public void testGetBoard()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        ListNode2<Space> set = null;
        g.setBoard( set );
        assertEquals( g.getBoard(), set );
    }


    /**
     * This method tests gameBoard getDice method
     */
    public void testGetDice()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        ArrayList<Die> myDice = new ArrayList<Die>();
        myDice.add( new Die() );
        myDice.add( new Die() );
        g.setDice( myDice );
        assertEquals( g.getDice(), myDice );
    }


    /**
     * This method tests gameBoard getGoJail method
     */
    public void testGetGoJail()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        ListNode2<Space> set = null;
        g.setGoJail( set );
        assertEquals( g.getGoJail(), set );
    }


    /**
     * This method tests the gameBoard getNumOfDoubles method
     */
    public void testGetNumOfDoubles()
    {
        GameBoard g = new GameBoard( s, 2, 0 );

    }


    /**
     * This method tests the gameBoard getProperty method
     */
    public void testGetProperty()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        ListNode2<Space> test = g.getProperty( "Boardwalk Avenue" );
        assertEquals( test.getValue().getName().equals( "Boardwalk Avenue" ),
            true );
    }


    /**
     * This method tests the gameBoard getSpace method
     */
    public void testGetSpace()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        ListNode2<Space> test = g.getSpace( "Electric Company Utility" );
        System.out.println( test.getValue().getName() );
        assertEquals( test.getValue().getName(), "Electric Company Utility" );
    }


    /**
     * This method tests the Player CurProperty method
     */
    public void testGetCurProperty()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        g.move( one, g.getSpace( "Electric Company Utility" ) );
        assertEquals( one.getCurrSpace().getValue().getName(),
            "Electric Company Utility" );

    }


    /**
     * This method tests the Player getInJail method
     */
    public void testGetInJail()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        g.move( one, g.getGoJail() );
        assertEquals( one.getCurrSpace(), g.getJail() );
    }


    /**
     * This method tests the Player getMoney method
     */
    public void testGetMoney()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        one.setMoney( 300 );
        assertEquals( one.getMoney(), 300 );
    }


    /**
     * This method tests the Player getMoveAmount method
     */
    public void testGetMoveAmount()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        one.setMoveAmount( 5 );
        assertEquals( one.getMoveAmount(), 5 );

    }


    /**
     * This method tests the Player getName method
     */
    public void testGetName()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        one.setName( "test" );
        assertEquals( one.getName(), "test" );
    }


    /**
     * This method tests the Player getNumHotels method
     */
    public void testGetNumHotels()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        one.setNumHotels( 3 );
        assertEquals( one.getNumHotels(), 3 );
    }


    /**
     * This method tests the Player getNumHouses method
     */
    public void testGetNumHouses()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        one.setNumHouses( 2 );
        assertEquals( one.getNumHouses(), 2 );
    }


    /**
     * This method tests the Player getPos method
     */
    public void testGetPos()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        one.setPos( 3 );
        assertEquals( one.getPos(), 3 );
    }


    /**
     * This method tests the Player getPrevPos method
     */
    public void testGetPrevPos()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        one.setPrevPos( 3 );
        assertEquals( one.getPrevPos(), 3 );
    }


    /**
     * This method tests the Player getProperties method
     */
    public void testGetProperties()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        one.buyProp( (PropertySpace)g.getProperty( "Boardwalk Avenue" )
            .getValue() );
        assertEquals( one.getProperties().get( one.getProperties().size() - 1 ),
            g.getProperty( "Boardwalk Avenue" ).getValue() );

    }


    /**
     * This method tests the Player getPropNum method
     */
    public void testGetPropNum()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        one.buyProp( (PropertySpace)g.getProperty( "Boardwalk Avenue" )
            .getValue() );
        assertEquals( one.getProperties().size(), one.getPropNum() );
    }


    /**
     * This method tests the Player getRailNum method
     */

    public void testGetRailNum()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        Space p = (Space)g.getProperty( "Reading Railroad" ).getValue();
        one.buyProp( (PropertySpace)g.getProperty( "Reading Railroad" )
            .getValue() );

    }


    /**
     * This method tests the Player getRailroads method
     */
    /**
     * public void testGetRailroads() { GameBoard g = new GameBoard(s, 2, 0);
     * Player one = g.getPlayers().remove(); one.buyRail((RailroadSpace)
     * g.getProperty("Reading Railroad") .getValue());
     * assertEquals(one.getRailroads().get(one.getRailroads().size() - 1), g
     * .getProperty("Reading Raildroad").getValue()); }
     **/

    /**
     * This method tests the Player getUtilities method
     */
    /**
     * public void testGetUtilities() { GameBoard g = new GameBoard(s, 2, 0);
     * Player one = g.getPlayers().remove(); one.buyUtil((UtilitySpace)
     * g.getProperty("Electric Company Utility") .getValue());
     * assertEquals(one.getUtilities().get(one.getUtilities().size() - 1),
     * (UtilitySpace) g.getProperty("Electric Company Utility") .getValue()); }
     **/

    /**
     * This method tests the Player getUtilNum method
     */
    public void testGetUtilNum()
    {
        // GameBoard g = new GameBoard(s, 2, 0);
        // Player one = g.getPlayers().remove();
        // one.buyUtil("Electric Company Utility");
        // assertEquals(one.getUtilNum(), 1);
    }


    /**
     * This method tests the Player hasAllPropsInGroup method
     */
    public void testHasAllPropsInGroup()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        one.buyProp( (PropertySpace)g.getProperty( "Atlantic Avenue" )
            .getValue() );
        one.buyProp( (PropertySpace)g.getProperty( "Ventnor Avenue" )
            .getValue() );
        one.buyProp( (PropertySpace)g.getProperty( "Marvin Gardens Avenue" )
            .getValue() );

    }


    /**
     * This method tests the Player testHasProp method
     */
    public void testHasProp()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        PropertySpace p = (PropertySpace)g.getProperty( "Boardwalk Avenue" )
            .getValue();
        one.buyProp( p );
        assertEquals( one.hasProp( p ), true );
    }


    /**
     * This method tests the Player move method
     */
    public void testMove()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        one.move( 5 );
        Space r = g.getSpace( "Reading Railroad" ).getValue();
        assertEquals( one.getCurrSpace().getValue(), r );
    }


    /**
     * This method tests the Player payBank method
     */
    public void testPayBank()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        int save = one.getMoney();
        one.payBank( 300 );
        assertEquals( one.getMoney(), save - 300 );
    }


    /**
     * This method tests the Player payPlayer method
     */
    public void testPayPlayer()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        Player two = g.getPlayers().remove();
        int save = one.getMoney();
        int save1 = two.getMoney();
        one.payPlayer( 100, two );
        assertEquals( one.getMoney(), save - 100 );
        assertEquals( two.getMoney(), save1 + 100 );
    }


    /**
     * This method tests the PropertySpace addHouse method
     */
    public void testAddHouse()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        PropertySpace p = (PropertySpace)g.getProperty( "Boardwalk Avenue" )
            .getValue();
        p.setOwner( one );
        one.buyProp( p );
        p.addHouse();
        assertEquals( p.hasHouses(), true );

    }


    /**
     * This method tests the PropertySpace getGroup method
     */
    public void testGetGroup()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        PropertySpace p = (PropertySpace)g.getProperty( "Boardwalk Avenue" )
            .getValue();
        p.setGroup( 8 );
        assertEquals( p.getGroup(), 8 );
    }


    /**
     * This method tests the PropertySpace getHousePrice method
     */
    public void testGetHousePrice()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        PropertySpace p = (PropertySpace)g.getProperty( "Boardwalk Avenue" )
            .getValue();
        p.setHousePrice( 100 );
        assertEquals( p.getHousePrice(), 100 );
    }


    /**
     * This method tests the PropertySpace testGetMortage
     */
    public void testGetMortgage()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        PropertySpace p = (PropertySpace)g.getProperty( "Boardwalk Avenue" )
            .getValue();
        p.setMortgage( 100 );
        assertEquals( p.getMortgage(), 100 );
    }


    /**
     * This method tests the PropertySpace getNumOfHouses method
     */
    public void testgetNumOfHouses()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        PropertySpace p = (PropertySpace)g.getProperty( "Boardwalk Avenue" )
            .getValue();
        p.setOwner( one );
        one.buyProp( p );
        p.addHouse();
        assertEquals( p.getNumOfHouses(), 1 );
    }


    /**
     * This method tests the PropertySpace Get Org Rent method
     */
    public void testGetOrgRent()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        PropertySpace p = (PropertySpace)g.getProperty( "Boardwalk Avenue" )
            .getValue();
        p.setOrgRent( 100 );
        assertEquals( p.getOrgRent(), 100 );
    }


    /**
     * This method tests the PropertySpace get owner method
     */
    public void testGetOwner()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        PropertySpace p = (PropertySpace)g.getProperty( "Boardwalk Avenue" )
            .getValue();
        p.setOwner( one );
        assertEquals( p.getOwner(), one );
    }


    /**
     * This method tests the PropertySpace getrent method
     */
    public void testGetRent()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        PropertySpace p = (PropertySpace)g.getProperty( "Boardwalk Avenue" )
            .getValue();
        p.setOwner( one );
        one.buyProp( p );
        int m = p.getOrgRent();
        p.addHouse();
        if ( p.getNumOfHouses() == 1 )
        {
            assertEquals( p.getRent( one ), m * 5 );
        }

    }


    /**
     * This method tests the PropertySpace HasHotel Boolean
     */
    public void testHasHotel()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        PropertySpace p = (PropertySpace)g.getProperty( "Boardwalk Avenue" )
            .getValue();
        p.setOwner( one );
        one.buyProp( p );
        int m = p.getOrgRent();
        for ( int i = 0; i < 5; i++ )
        {
            p.addHouse();
        }
        assertEquals( p.hasHotel(), true );
    }


    /**
     * This method tests the PropertySpace RemoveHouse method
     */
    public void testRemoveHouse()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        PropertySpace p = (PropertySpace)g.getProperty( "Boardwalk Avenue" )
            .getValue();
        p.setOwner( one );
        one.buyProp( p );
        p.addHouse();
        p.removeHouse();
        assertEquals( p.hasHouses(), false );
    }


    /**
     * This method tests the PropertySpace HasHouses boolean
     */
    public void testHasHouses()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        PropertySpace p = (PropertySpace)g.getProperty( "Boardwalk Avenue" )
            .getValue();
        p.setOwner( one );
        one.buyProp( p );
        p.addHouse();
        assertEquals( p.hasHouses(), true );
        p.removeHouse();
        assertEquals( p.hasHouses(), false );

    }


    /**
     * This method tests the PropertySpace set owner method
     */
    public void testSetOwner()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        PropertySpace p = (PropertySpace)g.getProperty( "Boardwalk Avenue" )
            .getValue();
        p.setOwner( one );
        assertEquals( p.getOwner(), one );
    }


    /**
     * This method tests whether a player is actually in jail.
     */
    public void testJail()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        ListNode2<Space> go = g.getGo();
        Player one = g.getPlayers().remove();

        g.move( one, g.getSpace( "Go to Jail" ) );
        one.setInJail( true );

        assertEquals( true, one.getInJail() );
        g.getPlayers().add( one );

    }


    /**
     * This method tests whether a player served only 3 turns in jail.
     */
    public void testJailTime()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        one.move( 10 );
        one.setInJail( true );
        g.getSpace( "Jail" ).getValue().act( one );
        assertEquals( ( (JailSpace)g.getSpace( "Jail" ).getValue() ).getTries() <= 3,
            true );

    }


    /**
     * This method tests whether the hotel price for a property is correct.
     */
    public void testHotelPrice()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        ListNode2<Space> go = g.getGo();
        PropertySpace one = (PropertySpace)g.getProperty( "Boardwalk Avenue" )
            .getValue();
        PropertySpace two = (PropertySpace)g.getProperty( "Baltic Avenue" )
            .getValue();
        PropertySpace three = (PropertySpace)g.getProperty( "New York Avenue" )
            .getValue();
        PropertySpace four = (PropertySpace)g.getProperty( "Indiana Avenue" )
            .getValue();

        assertEquals( 200, one.getHousePrice() );
        assertEquals( 50, two.getHousePrice() );
        assertEquals( 100, three.getHousePrice() );
        assertEquals( 150, four.getHousePrice() );

    }


    /**
     * This method tests whether or not a player rolled three doubles in a row.
     */
    public void testTripleDice()
    {
        GameBoard g = new GameBoard( s, 2, 0 );
        Player one = g.getPlayers().remove();
        assertEquals( g.getNumOfDoubles() == 3, one.getInJail() );

    }
}
