import java.util.*;


/**
 * This class creates the RailRoad Space on the GameBoard.
 *
 * @author William Wang, Aditya Kotak, Rahul Sarathy.
 * @version May 23, 2015
 * @author Period: 6
 * @author Assignment: MonopolyGame
 *
 * @author Sources: none
 */
public class RailroadSpace extends Space
{
    private Player owner;

    private Scanner in = new Scanner( System.in );

    private int mortgage;


    /**
     * Constructs a RailRoad space to be used in the Monopoly Game.
     * 
     * @param g
     *            The Gameboard this railroad will be used for.
     * @param rname
     *            The name of this RailRoad space.
     * @param rloc
     *            The integer location of this RailRoad space on the gameboard.
     */
    public RailroadSpace( GameBoard g, String rname, int rloc )
    {
        super( g, rloc );
        name = rname + " Railroad";
        buyable = true;
        canHaveBuildings = false;
        mortgage = 100;
    }


    /**
     * Returns a player who is the owner of this RailRoad space.
     * 
     * @return owner
     */
    public Player getOwner()
    {
        return owner;
    }


    /**
     * A required method since RailroadSpace extends Space that has the abstract
     * method act. This method enables Player p to purchase this railroad if
     * desired. This method will check if the player has enough money purchase
     * this property. If the owner is already set, then the Player p will pay
     * the owner the rent of this property based on the formula for multiplying
     * 50 to the number of railroad spaces owned by the owner.
     * 
     * @param p
     *            The Player who lands on this railroad space.
     */
    public void act( Player p )
    {
        boolean madeMove = false;
        playersOnSpace.add( p );

        if ( getOwner() == null )
        {
            if ( p.getMoney() >= 200 )
            {
                if ( p.isHuman )
                {
                    while ( !madeMove )
                    {
                        System.out.println( "You may buy this railroad! Price: $" + 200 );
                        System.out.println( "Please select an option:" );
                        System.out.println( "(1) Buy Railroad" );
                        System.out.println( "(2) Don't Buy Railroad" );
                        String ans = in.nextLine();
                        if ( ans.equals( "1" ) )
                        {
                            System.out.println( "Congrats you've bought this railroad" );
                            p.payBank( 200 );
                            p.buyRail( this );
                            setOwner( p );
                            System.out.println( "Money: $" + p.getMoney() );
                            System.out.println( "Properties: "
                                + p.getProperties() );
                            System.out.println( "Railroads: "
                                + p.getRailroads() );
                            System.out.println( "Utilities: "
                                + p.getUtilities() );
                            madeMove = true;
                        }
                        else if ( ans.equals( "2" ) )
                        {
                            System.out.println( "You did not buy this railroad." );
                            madeMove = true;
                        }
                        else
                        {
                            System.out.println( "Sorry, that is not a valid option. Please try again." );
                        }
                    }
                }
                else
                {
                    System.out.println( p.getName() + " bought " + getName()
                        + "." );
                    p.payBank( 200 );
                    p.buyRail( this );
                    setOwner( p );
                    System.out.println( "Money: $" + p.getMoney() );
                    System.out.println( "Properties: " + p.getProperties() );
                    System.out.println( "Railroads: " + p.getRailroads() );
                    System.out.println( "Utilities: " + p.getUtilities() );
                    madeMove = true;
                }
            }
            else
            {
                System.out.println( "Sorry, you do not have enough money to buy this railroad." );
            }
        }
        else
        {
            if ( !p.equals( getOwner() ) )
            {
                int pay = p.payPlayer( 50 * ( getOwner().getRailNum() ), owner );
                System.out.println( "You paid " + owner.getName() + " $" + pay
                    + "." );
            }
        }
    }


    /**
     * Sets a player who is the owner of this RailRoad space.
     * 
     * @param p
     *            the Player who owns this railroad
     */
    public void setOwner( Player p )
    {
        owner = p;
    }


    /**
     * Gets the mortgage amount of this railroad space
     * 
     * @return the mortgage value
     */
    public int getMortgage()
    {
        return mortgage;
    }
}
